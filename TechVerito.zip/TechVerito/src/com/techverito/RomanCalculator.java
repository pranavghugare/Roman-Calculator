package com.techverito;

public class RomanCalculator {

	public int DecimalConverter(String str) {
		int total = 0;
		int length = str.length();
		for (int i = 0; i < length; i++) {
			//end of the string
			if (i == length - 1) {
				total += getNumber(str.charAt(i));
				break;
			} else if (getNumber(str.charAt(i)) == getNumber(str.charAt(i + 1))) {
				total += getNumber(str.charAt(i));

			} else if (getNumber(str.charAt(i)) < getNumber(str.charAt(i + 1))) {
				total -= getNumber(str.charAt(i));

			} else {
				total += getNumber(str.charAt(i));

			}
		}
		return total;
	}

	public int getNumber(char c) {
		int number = 0;
		switch (String.valueOf(c)) {
		case "I":
			number = 1;
			break;
		case "V":
			number = 5;
			break;
		case "X":
			number = 10;
			break;
		case "L":
			number = 50;
			break;
		case "C":
			number = 100;
			break;
		case "D":
			number = 500;
			break;
		case "M":
			number = 1000;
			break;
		}
		return number;
	}

	// Addition of Roman Numbers
	public int Addition(String[] arr) {
		int Add = 0;
		for (int i = 0; i < arr.length; i++) {
			Add += DecimalConverter(arr[i]);
		}
		return Add;
	}

	// Multiplication of Roman Numbers
	public int Multiplication(String[] arr) {
		int Multi = 1;
		for (int i = 0; i < arr.length; i++) {
			Multi *= DecimalConverter(arr[i]);
		}
		return Multi;
	}

	// Substraction of Roman Numbers
	public int Substraction(String[] arr) {
		int sub = 0;
		int value = 0;
		for (int i = 0; i < arr.length; i++) {
			value = DecimalConverter(arr[i]);
			sub = Math.abs(value - sub);
		}
		return sub;
	}

	// Division of Roman Numbers
	public float Division(String[] arr) {
		float res = 0;

		for (int i = 0; i < arr.length; i++) {
			if (i == 0) {
				res = Integer.valueOf(DecimalConverter(arr[i]))
						/ ((float) Integer
								.valueOf(DecimalConverter(arr[i + 1])));
				i = 1;
			} else {
				res = res / Integer.valueOf(DecimalConverter(arr[i]));
			}
		}
		return res;
	}
	
}

