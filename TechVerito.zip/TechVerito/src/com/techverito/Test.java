package com.techverito;

import java.util.Scanner;

public class Test {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		RomanCalculator myClass = new RomanCalculator();

		System.out.println("1: Convert to Decimal Number");
		System.out.println("2: Addition");
		System.out.println("3: Substraction");
		System.out.println("4: Multiplication");
		System.out.println("5: Divide");

		do {
			System.out.println("Enter Your Choice");
			int iNo = sc.nextInt();
			System.out.println("Enter Number of Element");
			int input = sc.nextInt();

			String Arr[] = new String[input];
			System.out.println("Enter ROMAN Numbers");
			for (int i = 0; i < input; i++) {
				Arr[i] = sc.next();
			}
			switch (iNo) {
			case 1:
				for (int i = 0; i < input; i++) {
					System.out.println("Number in Decimal is:"
							+ myClass.DecimalConverter(Arr[i]));
				}
				break;
			case 2:
				System.out.println("Addition is:" + myClass.Addition(Arr));
				break;
			case 3:
				System.out.println("Addition is:" + myClass.Substraction(Arr));
				break;
			case 4:
				System.out.println("Multiplication is:"
						+ myClass.Multiplication(Arr));
				break;
			case 5:
				System.out
						.println("Multiplication is:" + myClass.Division(Arr));
				break;
			}

		} while (true);

	}

	
}
